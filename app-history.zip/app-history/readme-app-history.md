### Note

1app.py is working fine. But it still little strange for most people, because history chat shown as UUID. 


**2app.py is the most updated**  
This app is works perfectly. Choose this app to show to customer.